package battleShip.core.server.Database;

import battleShip.core.App;
import battleShip.models.Message;
import battleShip.models.Result;
import battleShip.models.Member;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;

public class DataBaseAPI extends SQLException {
    private static final String IMAGE_PATH = "D:" + File.separator +
            "3 курс" + File.separator +
            "BattleShip-Game-master" + File.separator +
            "BattleShip-Game-master" + File.separator +
            "battleShip" + File.separator +
            "core" + File.separator +
            "server" + File.separator +
            "Database" + File.separator +
            "images";

    private final static String DB_URL = "jdbc:postgresql://localhost:5432/DBBattleShip";
    static final String DB_USER = "postgres";
    static final String DB_PASSWORD ="murka2";
    static final String JDBC_DRIVER = "org.postgresql.Driver";

    public static App app;
    static Connection connection;

    static {connection = ConnectionForDB.getConnection();}

    public static Result addUserToDataBase(Member member) {
        try {
            //Connection connection = getConnection();
            String username = member.getUsername();
            String password = member.getPassword();
            int wins = member.getWins();
            int looses = member.getLooses();
            String fullName = member.getFullName();

//            PreparedStatement preparedStatement = connection.prepareStatement("insert into players values (?, ?, ?, ?, ?)");
//            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO players (\"Username\", \"Fullname\", \"Wins\", \"Loses\", \"Password\") VALUES (,?,?,?,?);\n");
            System.out.println(username);
            System.out.println(fullName);
            System.out.println(wins);
            System.out.println(looses);
            System.out.println(password);
//            preparedStatement.setString(1, username);
//            preparedStatement.setString(2, fullName);
//            preparedStatement.setInt(3, wins);
//            preparedStatement.setInt(4, looses);
//            preparedStatement.setString(5, password);

            Statement statement = connection.createStatement();
            statement.executeUpdate("INSERT INTO players (\"Username\", \"Fullname\", \"Wins\", \"Loses\", \"Password\") VALUES ('"+username+"','"+fullName+"',"+wins+","+looses+",'"+password+"');\n");
            statement.close();
            saveImage(member);

//            preparedStatement.execute();
            return Result.SUCCESS;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return Result.FAIL;
    }

    public static Member getMember(String findusername) {
        Member member = new Member();
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM players where \"Username\"='" + findusername + "'");

            while (resultSet.next()) {
                String username = resultSet.getString(2);
                String password = resultSet.getString(6);
                int wins = resultSet.getInt(4);
                int looses = resultSet.getInt(5);
                String fullname = resultSet.getString(3);

                member.setUsername(username);
                member.setPassword(password);
                member.setWins(wins);
                member.setLooses(looses);
                member.setFullName(fullname);
                setImage(member);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return member;
    }

    public static ArrayList<Member> getMembers() {
        ArrayList<Member> members = new ArrayList<>();
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from players");

            while (resultSet.next()) {
                String username = resultSet.getString(2);
                String password = resultSet.getString(6);
                int wins = resultSet.getInt(4);
                int looses = resultSet.getInt(5);
                String fullname = resultSet.getString(3);

                Member member = new Member();
                member.setUsername(username);
                member.setPassword(password);
                member.setWins(wins);
                member.setLooses(looses);
                member.setFullName(fullname);
                setImage(member);


                members.add(member);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return members;
    }

    private static void setImage(Member member) {
        File imageFile = null;
        for (File file : Paths.get(IMAGE_PATH).toFile().listFiles()) {
            if (file.getName().equals(member.getUsername())) {
                imageFile = file;
                break;
            }
        }

        if (imageFile == null)
            return;

        try {
            member.setImageData(Files.readAllBytes(imageFile.toPath()));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void saveImage(Member member) {
        for (File file : Paths.get(IMAGE_PATH).toFile().listFiles()) {
            if (file.getName().equals(member.getUsername()))
                file.delete();
        }

        try (FileOutputStream fos = new FileOutputStream(new File(IMAGE_PATH + File.separator + member.getUsername()))) {
            fos.write(member.getImageData());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static boolean refreshUserData(Member member) {
        System.out.println("db : datas refreshed");
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET \"Fullname\" =?,\"Wins\"=?,\"Loses\"=?,\"Password\"=? WHERE \"Username\"=?;");
            preparedStatement.setString(4, member.getPassword());
            preparedStatement.setInt(2, member.getWins());
            preparedStatement.setInt(3, member.getLooses());
            preparedStatement.setString(1, member.getFullName());
            preparedStatement.setString(5, member.getUsername());

            return preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }


}
