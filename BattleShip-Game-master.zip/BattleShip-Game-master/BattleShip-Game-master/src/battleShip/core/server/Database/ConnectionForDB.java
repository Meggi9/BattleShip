package battleShip.core.server.Database;

import java.io.File;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionForDB {

    private final static String DB_URL = "jdbc:postgresql://localhost:5432/DBBattleShip";
    static final String DB_USER = "postgres";
    static final String DB_PASSWORD ="murka2";
    static final String JDBC_DRIVER = "org.postgresql.Driver";

    public static Connection getConnection(){
        try {
            Class.forName(JDBC_DRIVER);
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Ошибка подключения!");
        } catch (ClassNotFoundException e) {
            System.out.println("Исключение Class!");
            e.printStackTrace();
        }
        return null;
    }
}
