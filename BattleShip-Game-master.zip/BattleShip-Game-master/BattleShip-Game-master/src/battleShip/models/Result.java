package battleShip.models;

public enum  Result {
    SUCCESS, DUPLICATE_USER, FAIL, attackWithPiece, attackWithoutPiece
}
