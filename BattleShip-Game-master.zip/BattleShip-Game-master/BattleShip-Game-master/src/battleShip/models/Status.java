package battleShip.models;

public enum Status {
    Online, Playing, Requested

}
